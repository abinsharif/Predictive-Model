
import numpy as np
import pandas as pd
import math
from datetime import datetime, timedelta
from sklearn.cluster import KMeans
from collections import defaultdict
import json

class GeographicModel:
    """Comprehensive geographic and terrain modeling system"""

    def __init__(self):
        self.terrain_data = self._load_terrain_data()
        self.climate_zones = self._load_climate_zones()
        self.elevation_effects = self._load_elevation_effects()
        self.geographic_vulnerabilities = self._load_geographic_vulnerabilities()

    def _load_terrain_data(self):
        """Load comprehensive terrain type data and characteristics"""
        return {
            'urban_dense': {
                'population_capacity_per_km2': 15000,
                'infrastructure_density': 0.95,
                'building_height_avg_m': 45,
                'green_space_percent': 12,
                'water_access_reliability': 0.92,
                'transportation_density': 0.88,
                'disaster_vulnerability': {
                    'earthquake': 0.85,
                    'flood': 0.75,
                    'fire': 0.90,
                    'conflict': 0.80
                },
                'economic_productivity': 2.8,
                'resource_dependencies': ['external_food', 'external_energy', 'external_materials']
            },
            'urban_medium': {
                'population_capacity_per_km2': 8000,
                'infrastructure_density': 0.78,
                'building_height_avg_m': 25,
                'green_space_percent': 25,
                'water_access_reliability': 0.88,
                'transportation_density': 0.72,
                'disaster_vulnerability': {
                    'earthquake': 0.70,
                    'flood': 0.65,
                    'fire': 0.75,
                    'conflict': 0.65
                },
                'economic_productivity': 2.2,
                'resource_dependencies': ['external_food', 'partial_energy']
            },
            'suburban': {
                'population_capacity_per_km2': 2500,
                'infrastructure_density': 0.62,
                'building_height_avg_m': 8,
                'green_space_percent': 45,
                'water_access_reliability': 0.82,
                'transportation_density': 0.55,
                'disaster_vulnerability': {
                    'earthquake': 0.45,
                    'flood': 0.50,
                    'fire': 0.60,
                    'conflict': 0.40
                },
                'economic_productivity': 1.5,
                'resource_dependencies': ['external_food', 'partial_energy']
            },
            'rural_agricultural': {
                'population_capacity_per_km2': 150,
                'infrastructure_density': 0.35,
                'building_height_avg_m': 4,
                'green_space_percent': 75,
                'water_access_reliability': 0.65,
                'transportation_density': 0.25,
                'disaster_vulnerability': {
                    'earthquake': 0.30,
                    'flood': 0.70,
                    'drought': 0.85,
                    'conflict': 0.50
                },
                'economic_productivity': 0.8,
                'resource_dependencies': ['weather_dependent'],
                'food_production_capacity': 2.5
            },
            'mountainous': {
                'population_capacity_per_km2': 80,
                'infrastructure_density': 0.25,
                'building_height_avg_m': 3,
                'green_space_percent': 85,
                'water_access_reliability': 0.75,
                'transportation_density': 0.15,
                'disaster_vulnerability': {
                    'earthquake': 0.80,
                    'landslide': 0.90,
                    'avalanche': 0.70,
                    'conflict': 0.35
                },
                'economic_productivity': 0.5,
                'resource_dependencies': ['external_food', 'external_materials'],
                'defensive_advantage': 2.2,
                'accessibility_factor': 0.3
            },
            'coastal': {
                'population_capacity_per_km2': 3500,
                'infrastructure_density': 0.68,
                'building_height_avg_m': 15,
                'green_space_percent': 35,
                'water_access_reliability': 0.85,
                'transportation_density': 0.78,
                'disaster_vulnerability': {
                    'tsunami': 0.95,
                    'hurricane': 0.88,
                    'sea_level_rise': 0.75,
                    'flood': 0.82
                },
                'economic_productivity': 2.1,
                'resource_dependencies': ['storm_protection'],
                'maritime_access': True,
                'fishing_capacity': 1.5
            },
            'desert': {
                'population_capacity_per_km2': 25,
                'infrastructure_density': 0.15,
                'building_height_avg_m': 2,
                'green_space_percent': 5,
                'water_access_reliability': 0.35,
                'transportation_density': 0.10,
                'disaster_vulnerability': {
                    'drought': 0.95,
                    'extreme_heat': 0.90,
                    'sandstorm': 0.75,
                    'conflict': 0.60
                },
                'economic_productivity': 0.3,
                'resource_dependencies': ['external_water', 'external_food'],
                'solar_energy_potential': 3.5,
                'mineral_extraction_potential': 2.0
            },
            'forest': {
                'population_capacity_per_km2': 60,
                'infrastructure_density': 0.20,
                'building_height_avg_m': 2,
                'green_space_percent': 92,
                'water_access_reliability': 0.80,
                'transportation_density': 0.12,
                'disaster_vulnerability': {
                    'wildfire': 0.90,
                    'flooding': 0.60,
                    'insect_outbreak': 0.70
                },
                'economic_productivity': 0.6,
                'resource_dependencies': ['fire_management'],
                'timber_production': 2.8,
                'carbon_sequestration': 3.2,
                'biodiversity_index': 4.5
            }
        }

    def _load_climate_zones(self):
        """Load climate zone characteristics and impacts"""
        return {
            'tropical': {
                'temperature_range_c': [20, 35],
                'humidity_avg_percent': 80,
                'precipitation_mm_year': 2500,
                'seasonal_variation': 'wet_dry',
                'agricultural_productivity': 2.2,
                'disease_risk_factor': 1.8,
                'construction_challenges': 1.4,
                'energy_cooling_demand': 2.5
            },
            'subtropical': {
                'temperature_range_c': [10, 30],
                'humidity_avg_percent': 65,
                'precipitation_mm_year': 1200,
                'seasonal_variation': 'moderate',
                'agricultural_productivity': 2.0,
                'disease_risk_factor': 1.2,
                'construction_challenges': 1.0,
                'energy_cooling_demand': 1.8
            },
            'temperate': {
                'temperature_range_c': [-5, 25],
                'humidity_avg_percent': 55,
                'precipitation_mm_year': 800,
                'seasonal_variation': 'four_seasons',
                'agricultural_productivity': 1.8,
                'disease_risk_factor': 1.0,
                'construction_challenges': 0.8,
                'energy_heating_demand': 1.5
            },
            'continental': {
                'temperature_range_c': [-20, 30],
                'humidity_avg_percent': 50,
                'precipitation_mm_year': 600,
                'seasonal_variation': 'extreme',
                'agricultural_productivity': 1.5,
                'disease_risk_factor': 0.8,
                'construction_challenges': 1.2,
                'energy_heating_demand': 2.5
            },
            'arid': {
                'temperature_range_c': [5, 45],
                'humidity_avg_percent': 25,
                'precipitation_mm_year': 200,
                'seasonal_variation': 'minimal',
                'agricultural_productivity': 0.3,
                'disease_risk_factor': 0.6,
                'construction_challenges': 1.6,
                'water_scarcity_factor': 3.5
            },
            'arctic': {
                'temperature_range_c': [-40, 10],
                'humidity_avg_percent': 70,
                'precipitation_mm_year': 400,
                'seasonal_variation': 'extreme_light',
                'agricultural_productivity': 0.1,
                'disease_risk_factor': 0.5,
                'construction_challenges': 2.8,
                'energy_heating_demand': 4.0
            }
        }

    def analyze_geographic_impact(self, location, terrain_type, climate_zone, elevation_m, impact_scenario):
        """Analyze comprehensive geographic impact on scenarios"""

        # Get terrain characteristics
        terrain_profile = self.terrain_data.get(terrain_type, self.terrain_data['suburban'])
        climate_profile = self.climate_zones.get(climate_zone, self.climate_zones['temperate'])

        # Calculate elevation effects
        elevation_effects = self._calculate_elevation_effects(elevation_m)

        # Calculate terrain-specific vulnerabilities
        terrain_vulnerabilities = self._calculate_terrain_vulnerabilities(
            terrain_profile, impact_scenario
        )

        # Calculate climate-related impacts
        climate_impacts = self._calculate_climate_impacts(
            climate_profile, impact_scenario
        )

        # Calculate accessibility and logistics factors
        logistics_factors = self._calculate_logistics_factors(
            terrain_profile, elevation_effects, climate_profile
        )

        # Calculate resource availability and constraints
        resource_analysis = self._calculate_resource_constraints(
            terrain_profile, climate_profile, elevation_effects
        )

        return {
            'location': location,
            'terrain_type': terrain_type,
            'climate_zone': climate_zone,
            'elevation_m': elevation_m,
            'terrain_profile': terrain_profile,
            'climate_profile': climate_profile,
            'elevation_effects': elevation_effects,
            'terrain_vulnerabilities': terrain_vulnerabilities,
            'climate_impacts': climate_impacts,
            'logistics_factors': logistics_factors,
            'resource_analysis': resource_analysis,
            'strategic_assessment': self._generate_strategic_assessment(
                terrain_profile, climate_profile, elevation_effects, impact_scenario
            )
        }

    def _calculate_elevation_effects(self, elevation_m):
        """Calculate effects of elevation on various factors"""

        if elevation_m < 500:
            elevation_category = 'lowland'
            accessibility_factor = 1.0
            construction_difficulty = 1.0
            weather_severity = 1.0
        elif elevation_m < 1500:
            elevation_category = 'highland'
            accessibility_factor = 0.8
            construction_difficulty = 1.3
            weather_severity = 1.2
        elif elevation_m < 3000:
            elevation_category = 'mountain'
            accessibility_factor = 0.5
            construction_difficulty = 1.8
            weather_severity = 1.6
        else:
            elevation_category = 'high_mountain'
            accessibility_factor = 0.2
            construction_difficulty = 2.5
            weather_severity = 2.2

        # Calculate atmospheric effects
        air_density_factor = math.exp(-elevation_m / 8400)  # Barometric formula
        temperature_drop_c = elevation_m * 0.0065  # Lapse rate

        return {
            'elevation_category': elevation_category,
            'accessibility_factor': accessibility_factor,
            'construction_difficulty': construction_difficulty,
            'weather_severity_multiplier': weather_severity,
            'air_density_factor': air_density_factor,
            'temperature_reduction_c': temperature_drop_c,
            'oxygen_availability': air_density_factor,
            'precipitation_enhancement': 1 + (elevation_m / 2000) * 0.3  # Orographic effect
        }

    def _calculate_terrain_vulnerabilities(self, terrain_profile, impact_scenario):
        """Calculate terrain-specific vulnerabilities to impact scenario"""

        scenario_type = impact_scenario.get('type', 'conflict')
        intensity = impact_scenario.get('intensity', 'medium')

        # Get base vulnerabilities for this terrain
        disaster_vulnerabilities = terrain_profile.get('disaster_vulnerability', {})

        # Calculate scenario-specific vulnerability
        vulnerability_factors = {}

        if scenario_type == 'conflict':
            # Military factors
            vulnerability_factors['military_accessibility'] = 1.0 - terrain_profile.get('defensive_advantage', 1.0) / 3.0
            vulnerability_factors['civilian_exposure'] = terrain_profile['infrastructure_density']
            vulnerability_factors['supply_line_vulnerability'] = 1.0 - terrain_profile.get('accessibility_factor', 1.0)
            vulnerability_factors['strategic_value'] = terrain_profile['economic_productivity']

        elif scenario_type == 'natural_disaster':
            # Natural disaster vulnerabilities
            for disaster_type, vulnerability in disaster_vulnerabilities.items():
                vulnerability_factors[disaster_type] = vulnerability

        elif scenario_type == 'economic_collapse':
            # Economic vulnerabilities
            vulnerability_factors['resource_dependency'] = len(terrain_profile.get('resource_dependencies', []))
            vulnerability_factors['economic_diversification'] = 1.0 / max(0.1, terrain_profile['economic_productivity'])
            vulnerability_factors['infrastructure_maintenance'] = terrain_profile['infrastructure_density']

        # Apply intensity multipliers
        intensity_multipliers = {'low': 0.6, 'medium': 1.0, 'high': 1.4, 'extreme': 1.8}
        multiplier = intensity_multipliers[intensity]

        for factor, value in vulnerability_factors.items():
            vulnerability_factors[factor] = min(1.0, value * multiplier)

        return vulnerability_factors

    def _calculate_climate_impacts(self, climate_profile, impact_scenario):
        """Calculate climate-related impacts on scenario"""

        scenario_type = impact_scenario.get('type', 'conflict')
        intensity = impact_scenario.get('intensity', 'medium')
        duration = impact_scenario.get('duration_days', 30)

        climate_impacts = {}

        # Temperature effects
        temp_range = climate_profile['temperature_range_c']
        avg_temp = (temp_range[0] + temp_range[1]) / 2

        if avg_temp > 30:  # Hot climate
            climate_impacts['heat_stress_factor'] = 1.8
            climate_impacts['equipment_degradation'] = 1.4
            climate_impacts['energy_demand_cooling'] = climate_profile.get('energy_cooling_demand', 1.0)
        elif avg_temp < 5:  # Cold climate
            climate_impacts['cold_stress_factor'] = 1.6
            climate_impacts['equipment_challenges'] = 1.5
            climate_impacts['energy_demand_heating'] = climate_profile.get('energy_heating_demand', 1.0)
        else:  # Moderate climate
            climate_impacts['temperature_stress'] = 1.0

        # Humidity effects
        humidity = climate_profile['humidity_avg_percent']
        if humidity > 75:
            climate_impacts['disease_risk_multiplier'] = climate_profile.get('disease_risk_factor', 1.0)
            climate_impacts['equipment_corrosion'] = 1.3
            climate_impacts['comfort_factor'] = 0.7

        # Precipitation effects
        precipitation = climate_profile['precipitation_mm_year']
        if precipitation > 2000:
            climate_impacts['flood_risk'] = 1.6
            climate_impacts['transportation_disruption'] = 1.4
        elif precipitation < 400:
            climate_impacts['drought_risk'] = 1.8
            climate_impacts['water_scarcity'] = climate_profile.get('water_scarcity_factor', 1.0)

        # Seasonal variation effects
        seasonal_variation = climate_profile['seasonal_variation']
        if seasonal_variation in ['extreme', 'extreme_light']:
            climate_impacts['seasonal_planning_complexity'] = 1.8
            climate_impacts['resource_storage_needs'] = 2.2

        # Apply scenario-specific climate interactions
        if scenario_type == 'conflict' and duration > 90:  # Long-term conflict
            # Weather becomes more significant in extended operations
            for factor, value in climate_impacts.items():
                if 'stress' in factor or 'risk' in factor:
                    climate_impacts[factor] = min(3.0, value * 1.5)

        return climate_impacts

class ClimateImpactModel:
    """Climate change impact and environmental degradation modeling"""

    def __init__(self):
        self.climate_scenarios = self._load_climate_scenarios()
        self.environmental_thresholds = self._load_environmental_thresholds()
        self.adaptation_measures = self._load_adaptation_measures()

    def _load_climate_scenarios(self):
        """Load climate change scenario projections"""
        return {
            'rcp26': {  # Low emissions scenario
                'global_temp_increase_c': 1.8,
                'sea_level_rise_cm': 43,
                'precipitation_change_percent': {'global_avg': 2.5, 'variability_increase': 15},
                'extreme_weather_frequency_multiplier': 1.4,
                'agricultural_productivity_change': -0.05,
                'water_stress_regions_percent': 25
            },
            'rcp45': {  # Moderate emissions scenario
                'global_temp_increase_c': 2.4,
                'sea_level_rise_cm': 56,
                'precipitation_change_percent': {'global_avg': 3.8, 'variability_increase': 25},
                'extreme_weather_frequency_multiplier': 2.1,
                'agricultural_productivity_change': -0.12,
                'water_stress_regions_percent': 35
            },
            'rcp60': {  # High emissions scenario
                'global_temp_increase_c': 3.2,
                'sea_level_rise_cm': 72,
                'precipitation_change_percent': {'global_avg': 5.1, 'variability_increase': 35},
                'extreme_weather_frequency_multiplier': 2.8,
                'agricultural_productivity_change': -0.22,
                'water_stress_regions_percent': 48
            },
            'rcp85': {  # Very high emissions scenario
                'global_temp_increase_c': 4.3,
                'sea_level_rise_cm': 98,
                'precipitation_change_percent': {'global_avg': 7.2, 'variability_increase': 45},
                'extreme_weather_frequency_multiplier': 3.6,
                'agricultural_productivity_change': -0.35,
                'water_stress_regions_percent': 65
            }
        }

    def model_climate_impact_scenario(self, region, time_horizon_years, emission_scenario, population_profile):
        """Model comprehensive climate impact scenario"""

        # Get climate projection for scenario
        climate_projection = self.climate_scenarios.get(emission_scenario, self.climate_scenarios['rcp45'])

        # Scale projections to time horizon
        time_scale_factor = time_horizon_years / 80  # Most projections are for 2100 (80 years from 2020)

        scaled_projection = {}
        for key, value in climate_projection.items():
            if isinstance(value, (int, float)):
                scaled_projection[key] = value * time_scale_factor
            else:
                scaled_projection[key] = value

        # Calculate regional-specific impacts
        regional_impacts = self._calculate_regional_climate_impacts(
            region, scaled_projection, population_profile
        )

        # Calculate infrastructure impacts
        infrastructure_impacts = self._calculate_infrastructure_climate_impacts(
            scaled_projection, population_profile
        )

        # Calculate human impact
        human_impacts = self._calculate_human_climate_impacts(
            regional_impacts, infrastructure_impacts, population_profile
        )

        # Calculate economic impacts
        economic_impacts = self._calculate_economic_climate_impacts(
            regional_impacts, time_horizon_years, population_profile
        )

        # Calculate adaptation requirements
        adaptation_needs = self._calculate_adaptation_requirements(
            regional_impacts, human_impacts, economic_impacts
        )

        return {
            'emission_scenario': emission_scenario,
            'time_horizon_years': time_horizon_years,
            'climate_projection': scaled_projection,
            'regional_impacts': regional_impacts,
            'infrastructure_impacts': infrastructure_impacts,
            'human_impacts': human_impacts,
            'economic_impacts': economic_impacts,
            'adaptation_needs': adaptation_needs,
            'migration_pressure': self._calculate_climate_migration(regional_impacts, population_profile),
            'conflict_risk': self._calculate_climate_conflict_risk(regional_impacts, human_impacts)
        }

    def _calculate_regional_climate_impacts(self, region, projection, population_profile):
        """Calculate region-specific climate impacts"""

        # Regional vulnerability factors (simplified)
        regional_factors = {
            'south_asia': {
                'heat_vulnerability': 1.8,
                'flood_vulnerability': 2.2,
                'drought_vulnerability': 1.6,
                'sea_level_vulnerability': 2.0,
                'monsoon_disruption_factor': 2.5
            },
            'middle_east': {
                'heat_vulnerability': 2.5,
                'drought_vulnerability': 2.8,
                'water_scarcity_multiplier': 3.2,
                'desertification_rate': 2.0,
                'temperature_extreme_factor': 2.2
            },
            'sub_saharan_africa': {
                'drought_vulnerability': 2.4,
                'flood_vulnerability': 1.8,
                'agricultural_impact_multiplier': 2.6,
                'water_stress_factor': 2.1,
                'ecosystem_degradation': 2.0
            },
            'small_island_states': {
                'sea_level_vulnerability': 4.5,
                'storm_intensity_multiplier': 3.2,
                'freshwater_contamination': 3.8,
                'land_loss_rate': 4.0
            }
        }

        factors = regional_factors.get(region, regional_factors['south_asia'])

        regional_impacts = {}

        # Temperature impacts
        temp_increase = projection['global_temp_increase_c']
        regional_impacts['temperature'] = {
            'increase_c': temp_increase * factors.get('temperature_extreme_factor', 1.0),
            'heat_days_increase': temp_increase * 15 * factors.get('heat_vulnerability', 1.0),
            'cooling_degree_days_increase': temp_increase * 200,
            'agricultural_heat_stress': temp_increase * factors.get('agricultural_impact_multiplier', 1.0)
        }

        # Precipitation impacts
        precip_change = projection['precipitation_change_percent']['global_avg']
        regional_impacts['precipitation'] = {
            'annual_change_percent': precip_change,
            'variability_increase': projection['precipitation_change_percent']['variability_increase'],
            'drought_frequency_multiplier': factors.get('drought_vulnerability', 1.0),
            'flood_frequency_multiplier': factors.get('flood_vulnerability', 1.0)
        }

        # Sea level impacts (if applicable)
        if 'sea_level_vulnerability' in factors:
            sea_level_rise = projection['sea_level_rise_cm']
            regional_impacts['sea_level'] = {
                'rise_cm': sea_level_rise * factors['sea_level_vulnerability'],
                'coastal_area_affected_km2': sea_level_rise * 0.8 * factors['sea_level_vulnerability'],
                'population_at_risk': int(population_profile['actual_population'] * 0.1 * factors['sea_level_vulnerability'])
            }

        return regional_impacts

    def _calculate_infrastructure_climate_impacts(self, projection, population_profile):
        """Calculate climate impacts on infrastructure"""

        temp_increase = projection['global_temp_increase_c']
        extreme_weather_mult = projection['extreme_weather_frequency_multiplier']

        infrastructure_impacts = {
            'transportation': {
                'road_damage_increase_percent': temp_increase * 15 + extreme_weather_mult * 10,
                'bridge_stress_factor': 1 + temp_increase * 0.3,
                'airport_disruption_days_per_year': extreme_weather_mult * 8,
                'maintenance_cost_increase_percent': temp_increase * 20 + extreme_weather_mult * 15
            },
            'energy': {
                'power_grid_stress_events_per_year': extreme_weather_mult * 12,
                'cooling_demand_increase_percent': temp_increase * 25,
                'renewable_energy_potential_change': {
                    'solar': temp_increase * 5,  # Higher temps reduce efficiency but more sun hours
                    'wind': -extreme_weather_mult * 8,  # More extreme weather affects turbines
                    'hydro': -projection['precipitation_change_percent']['global_avg'] * 2
                },
                'grid_resilience_investment_needed_percent': extreme_weather_mult * 30
            },
            'water_systems': {
                'treatment_capacity_stress': temp_increase * 0.8 + extreme_weather_mult * 0.4,
                'distribution_system_failures_increase': extreme_weather_mult * 45,
                'storage_evaporation_increase_percent': temp_increase * 12,
                'quality_control_challenges': temp_increase * 1.5
            },
            'buildings': {
                'structural_stress_increase': temp_increase * 0.6 + extreme_weather_mult * 0.8,
                'hvac_system_oversizing_needed_percent': temp_increase * 18,
                'material_degradation_acceleration': temp_increase * 1.4,
                'insurance_costs_increase_percent': extreme_weather_mult * 35
            }
        }

        return infrastructure_impacts

class InfrastructureModel:
    """Infrastructure modeling and impact analysis system"""

    def __init__(self):
        self.infrastructure_types = self._load_infrastructure_types()
        self.interdependency_matrix = self._load_infrastructure_interdependencies()
        self.capacity_models = self._load_capacity_models()

    def _load_infrastructure_types(self):
        """Load comprehensive infrastructure type definitions"""
        return {
            'transportation': {
                'roads': {
                    'capacity_metric': 'vehicles_per_hour',
                    'vulnerability_factors': ['weather', 'seismic', 'conflict'],
                    'maintenance_cycle_months': 18,
                    'replacement_cost_per_km': 2500000,
                    'criticality_score': 8.5,
                    'redundancy_typical': 0.6
                },
                'railways': {
                    'capacity_metric': 'passengers_per_hour',
                    'vulnerability_factors': ['weather', 'seismic', 'cyber'],
                    'maintenance_cycle_months': 12,
                    'replacement_cost_per_km': 15000000,
                    'criticality_score': 7.8,
                    'redundancy_typical': 0.3
                },
                'airports': {
                    'capacity_metric': 'flights_per_day',
                    'vulnerability_factors': ['weather', 'conflict', 'cyber'],
                    'maintenance_cycle_months': 6,
                    'replacement_cost_per_facility': 2000000000,
                    'criticality_score': 9.2,
                    'redundancy_typical': 0.2
                },
                'ports': {
                    'capacity_metric': 'containers_per_day',
                    'vulnerability_factors': ['weather', 'sea_level', 'conflict'],
                    'maintenance_cycle_months': 24,
                    'replacement_cost_per_facility': 5000000000,
                    'criticality_score': 9.0,
                    'redundancy_typical': 0.4
                }
            },
            'energy': {
                'power_generation': {
                    'capacity_metric': 'megawatts',
                    'vulnerability_factors': ['weather', 'cyber', 'supply_chain'],
                    'maintenance_cycle_months': 8,
                    'replacement_cost_per_mw': 3000000,
                    'criticality_score': 9.8,
                    'redundancy_typical': 0.25
                },
                'transmission_grid': {
                    'capacity_metric': 'mw_transmission',
                    'vulnerability_factors': ['weather', 'cyber', 'physical'],
                    'maintenance_cycle_months': 12,
                    'replacement_cost_per_km': 800000,
                    'criticality_score': 9.5,
                    'redundancy_typical': 0.15
                },
                'distribution_grid': {
                    'capacity_metric': 'local_distribution',
                    'vulnerability_factors': ['weather', 'aging', 'overload'],
                    'maintenance_cycle_months': 18,
                    'replacement_cost_per_km': 150000,
                    'criticality_score': 8.8,
                    'redundancy_typical': 0.3
                }
            },
            'water_systems': {
                'treatment_plants': {
                    'capacity_metric': 'liters_per_day',
                    'vulnerability_factors': ['contamination', 'power', 'chemicals'],
                    'maintenance_cycle_months': 6,
                    'replacement_cost_per_facility': 50000000,
                    'criticality_score': 9.4,
                    'redundancy_typical': 0.2
                },
                'distribution_network': {
                    'capacity_metric': 'flow_rate',
                    'vulnerability_factors': ['aging', 'pressure', 'contamination'],
                    'maintenance_cycle_months': 36,
                    'replacement_cost_per_km': 400000,
                    'criticality_score': 8.9,
                    'redundancy_typical': 0.1
                },
                'storage_systems': {
                    'capacity_metric': 'storage_volume',
                    'vulnerability_factors': ['seismic', 'contamination', 'evaporation'],
                    'maintenance_cycle_months': 60,
                    'replacement_cost_per_facility': 25000000,
                    'criticality_score': 8.6,
                    'redundancy_typical': 0.4
                }
            },
            'telecommunications': {
                'cellular_networks': {
                    'capacity_metric': 'users_served',
                    'vulnerability_factors': ['power', 'cyber', 'physical'],
                    'maintenance_cycle_months': 12,
                    'replacement_cost_per_tower': 500000,
                    'criticality_score': 8.7,
                    'redundancy_typical': 0.8
                },
                'fiber_networks': {
                    'capacity_metric': 'bandwidth_gbps',
                    'vulnerability_factors': ['physical', 'cyber', 'power'],
                    'maintenance_cycle_months': 24,
                    'replacement_cost_per_km': 50000,
                    'criticality_score': 9.1,
                    'redundancy_typical': 0.6
                },
                'data_centers': {
                    'capacity_metric': 'processing_power',
                    'vulnerability_factors': ['power', 'cooling', 'cyber'],
                    'maintenance_cycle_months': 3,
                    'replacement_cost_per_facility': 100000000,
                    'criticality_score': 9.6,
                    'redundancy_typical': 0.9
                }
            }
        }

    def analyze_infrastructure_impact(self, infrastructure_profile, impact_scenario, geographic_factors):
        """Analyze comprehensive infrastructure impact"""

        scenario_type = impact_scenario.get('type', 'conflict')
        intensity = impact_scenario.get('intensity', 'medium')
        duration = impact_scenario.get('duration_days', 30)

        # Calculate direct infrastructure damage
        direct_damage = self._calculate_direct_infrastructure_damage(
            infrastructure_profile, scenario_type, intensity
        )

        # Calculate cascade failures
        cascade_failures = self._calculate_infrastructure_cascades(
            direct_damage, self.interdependency_matrix
        )

        # Calculate service disruptions
        service_disruptions = self._calculate_service_disruptions(
            direct_damage, cascade_failures, duration
        )

        # Calculate repair and recovery requirements
        recovery_analysis = self._calculate_infrastructure_recovery(
            direct_damage, cascade_failures, geographic_factors
        )

        # Calculate economic impact of infrastructure loss
        economic_impact = self._calculate_infrastructure_economic_impact(
            service_disruptions, recovery_analysis, infrastructure_profile
        )

        return {
            'infrastructure_profile': infrastructure_profile,
            'impact_scenario': impact_scenario,
            'direct_damage': direct_damage,
            'cascade_failures': cascade_failures,
            'service_disruptions': service_disruptions,
            'recovery_analysis': recovery_analysis,
            'economic_impact': economic_impact,
            'critical_path_analysis': self._identify_critical_infrastructure_paths(direct_damage, cascade_failures),
            'resilience_recommendations': self._generate_resilience_recommendations(direct_damage, cascade_failures)
        }

    def _calculate_direct_infrastructure_damage(self, infrastructure_profile, scenario_type, intensity):
        """Calculate direct damage to infrastructure systems"""

        # Damage rate matrices by scenario type and intensity
        damage_matrices = {
            'conflict': {
                'transportation': {'low': 0.15, 'medium': 0.35, 'high': 0.65, 'extreme': 0.85},
                'energy': {'low': 0.25, 'medium': 0.50, 'high': 0.75, 'extreme': 0.90},
                'telecommunications': {'low': 0.30, 'medium': 0.55, 'high': 0.80, 'extreme': 0.95},
                'water_systems': {'low': 0.10, 'medium': 0.25, 'high': 0.50, 'extreme': 0.75}
            },
            'natural_disaster': {
                'transportation': {'low': 0.20, 'medium': 0.45, 'high': 0.70, 'extreme': 0.90},
                'energy': {'low': 0.30, 'medium': 0.60, 'high': 0.80, 'extreme': 0.95},
                'telecommunications': {'low': 0.25, 'medium': 0.50, 'high': 0.75, 'extreme': 0.90},
                'water_systems': {'low': 0.35, 'medium': 0.65, 'high': 0.85, 'extreme': 0.95}
            },
            'cyber_attack': {
                'energy': {'low': 0.05, 'medium': 0.20, 'high': 0.50, 'extreme': 0.80},
                'telecommunications': {'low': 0.15, 'medium': 0.40, 'high': 0.70, 'extreme': 0.90},
                'water_systems': {'low': 0.02, 'medium': 0.10, 'high': 0.30, 'extreme': 0.60},
                'transportation': {'low': 0.01, 'medium': 0.08, 'high': 0.25, 'extreme': 0.50}
            }
        }

        scenario_damage = damage_matrices.get(scenario_type, damage_matrices['conflict'])

        direct_damage = {}

        for infrastructure_type, systems in self.infrastructure_types.items():
            if infrastructure_type in scenario_damage:
                damage_rate = scenario_damage[infrastructure_type][intensity]

                direct_damage[infrastructure_type] = {
                    'damage_rate': damage_rate,
                    'systems_affected': {},
                    'total_replacement_cost': 0,
                    'capacity_lost_percent': damage_rate * 100
                }

                # Calculate system-specific damage
                for system_name, system_data in systems.items():
                    system_damage_rate = damage_rate * np.random.uniform(0.7, 1.3)  # Add variability
                    system_damage_rate = min(1.0, system_damage_rate)

                    replacement_cost = system_data.get('replacement_cost_per_facility', 
                                                     system_data.get('replacement_cost_per_km', 
                                                     system_data.get('replacement_cost_per_mw', 1000000)))

                    direct_damage[infrastructure_type]['systems_affected'][system_name] = {
                        'damage_rate': system_damage_rate,
                        'criticality_score': system_data['criticality_score'],
                        'redundancy_available': system_data['redundancy_typical'],
                        'replacement_cost': replacement_cost * system_damage_rate,
                        'repair_time_months': system_data['maintenance_cycle_months'] * system_damage_rate * 2
                    }

                    direct_damage[infrastructure_type]['total_replacement_cost'] += replacement_cost * system_damage_rate

        return direct_damage

    def _calculate_infrastructure_cascades(self, direct_damage, interdependency_matrix):
        """Calculate cascade failures through infrastructure interdependencies"""

        # Simplified interdependency matrix
        dependencies = {
            'energy': ['telecommunications', 'water_systems', 'transportation'],
            'telecommunications': ['energy'],
            'water_systems': ['energy', 'telecommunications'],
            'transportation': ['energy', 'telecommunications']
        }

        cascade_failures = {}

        for damaged_infrastructure, damage_info in direct_damage.items():
            damage_rate = damage_info['damage_rate']

            # Calculate cascade effects on dependent systems
            dependent_systems = dependencies.get(damaged_infrastructure, [])

            for dependent_system in dependent_systems:
                if dependent_system not in cascade_failures:
                    cascade_failures[dependent_system] = {
                        'cascade_sources': [],
                        'total_cascade_impact': 0,
                        'functionality_reduction': 0
                    }

                # Calculate cascade impact (reduced by dependency strength)
                cascade_impact = damage_rate * 0.6  # 60% of damage cascades

                cascade_failures[dependent_system]['cascade_sources'].append({
                    'source': damaged_infrastructure,
                    'impact': cascade_impact
                })

                cascade_failures[dependent_system]['total_cascade_impact'] = max(
                    cascade_failures[dependent_system]['total_cascade_impact'],
                    cascade_impact
                )

                # Cumulative functionality reduction
                cascade_failures[dependent_system]['functionality_reduction'] += cascade_impact * 0.5

        # Cap functionality reduction at 100%
        for system, cascade_info in cascade_failures.items():
            cascade_info['functionality_reduction'] = min(1.0, cascade_info['functionality_reduction'])

        return cascade_failures

    def _calculate_service_disruptions(self, direct_damage, cascade_failures, duration_days):
        """Calculate service disruptions to population"""

        service_disruptions = {}

        # Map infrastructure to services
        infrastructure_to_services = {
            'energy': ['electricity', 'heating', 'industrial_power'],
            'water_systems': ['potable_water', 'sanitation', 'industrial_water'],
            'telecommunications': ['internet', 'mobile_phone', 'emergency_communications'],
            'transportation': ['public_transit', 'freight', 'emergency_services']
        }

        for infrastructure_type, services in infrastructure_to_services.items():
            # Get disruption rate from direct damage
            disruption_rate = 0
            if infrastructure_type in direct_damage:
                disruption_rate = direct_damage[infrastructure_type]['damage_rate']

            # Add cascade effects
            if infrastructure_type in cascade_failures:
                disruption_rate += cascade_failures[infrastructure_type]['functionality_reduction']

            disruption_rate = min(1.0, disruption_rate)

            if disruption_rate > 0.05:  # Only record significant disruptions
                service_disruptions[infrastructure_type] = {
                    'disruption_rate': disruption_rate,
                    'services_affected': services,
                    'population_impact_percent': disruption_rate * 100,
                    'estimated_duration_days': duration_days * disruption_rate,
                    'service_degradation': {
                        service: {
                            'availability_percent': (1 - disruption_rate) * 100,
                            'quality_impact': disruption_rate,
                            'backup_systems_activated': disruption_rate > 0.3
                        } for service in services
                    }
                }

        return service_disruptions
