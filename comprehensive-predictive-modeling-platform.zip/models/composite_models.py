
import numpy as np
import pandas as pd
import json
from datetime import datetime, timedelta
from collections import defaultdict
import threading
import time
import uuid

from .military_models import MilitaryAnalyzer, NuclearWarfareModel, DefenseSystemModel
from .economic_models import EconomicImpactModel, SupplyChainModel, MarketDisruptionModel
from .social_models import PopulationModel, PsychologicalImpactModel, CulturalModel
from .environmental_models import GeographicModel, ClimateImpactModel, InfrastructureModel

class CompositeScenarioModel:
    """Master composite model that orchestrates all individual models for complex scenarios"""

    def __init__(self):
        # Initialize all component models
        self.military_analyzer = MilitaryAnalyzer()
        self.nuclear_model = NuclearWarfareModel()
        self.defense_model = DefenseSystemModel()
        self.economic_model = EconomicImpactModel()
        self.supply_chain_model = SupplyChainModel()
        self.market_model = MarketDisruptionModel()
        self.population_model = PopulationModel()
        self.psychological_model = PsychologicalImpactModel()
        self.cultural_model = CulturalModel()
        self.geographic_model = GeographicModel()
        self.climate_model = ClimateImpactModel()
        self.infrastructure_model = InfrastructureModel()

        # Initialize escalation and response models
        self.escalation_model = EscalationModel()
        self.global_response_model = GlobalResponseModel()

        self.scenario_cache = {}

    def run_comprehensive_analysis(self, scenario_config):
        """Run comprehensive analysis using multiple interconnected models"""

        scenario_id = scenario_config.get('id', str(uuid.uuid4()))
        scenario_type = scenario_config.get('type', 'conflict')

        print(f"Starting comprehensive analysis for scenario: {scenario_id}")

        # Initialize results structure
        comprehensive_results = {
            'scenario_id': scenario_id,
            'scenario_config': scenario_config,
            'analysis_start_time': datetime.now().isoformat(),
            'model_results': {},
            'integrated_analysis': {},
            'timeline_projections': {},
            'risk_assessment': {},
            'policy_recommendations': {}
        }

        try:
            # Phase 1: Run all individual model analyses
            print("Phase 1: Running individual model analyses...")
            comprehensive_results['model_results'] = self._run_individual_models(scenario_config)

            # Phase 2: Integrate results across models
            print("Phase 2: Integrating cross-model interactions...")
            comprehensive_results['integrated_analysis'] = self._integrate_model_results(
                comprehensive_results['model_results'], scenario_config
            )

            # Phase 3: Generate timeline projections
            print("Phase 3: Generating timeline projections...")
            comprehensive_results['timeline_projections'] = self._generate_timeline_projections(
                comprehensive_results['integrated_analysis'], scenario_config
            )

            # Phase 4: Assess overall risks and uncertainties
            print("Phase 4: Assessing risks and uncertainties...")
            comprehensive_results['risk_assessment'] = self._assess_comprehensive_risks(
                comprehensive_results['integrated_analysis']
            )

            # Phase 5: Generate policy recommendations
            print("Phase 5: Generating policy recommendations...")
            comprehensive_results['policy_recommendations'] = self._generate_policy_recommendations(
                comprehensive_results['integrated_analysis'], comprehensive_results['risk_assessment']
            )

            # Phase 6: Calculate confidence levels
            comprehensive_results['confidence_analysis'] = self._calculate_confidence_levels(
                comprehensive_results['model_results']
            )

            comprehensive_results['analysis_end_time'] = datetime.now().isoformat()
            comprehensive_results['status'] = 'completed'

            # Cache results
            self.scenario_cache[scenario_id] = comprehensive_results

            print(f"Comprehensive analysis completed for scenario: {scenario_id}")

            return comprehensive_results

        except Exception as e:
            comprehensive_results['status'] = 'error'
            comprehensive_results['error'] = str(e)
            comprehensive_results['analysis_end_time'] = datetime.now().isoformat()
            print(f"Error in comprehensive analysis: {e}")
            return comprehensive_results

    def _run_individual_models(self, scenario_config):
        """Run all individual models based on scenario configuration"""

        model_results = {}
        scenario_type = scenario_config.get('type', 'conflict')

        # Geographic and environmental analysis (always runs first)
        print("  Running geographic analysis...")
        if 'location' in scenario_config:
            model_results['geographic'] = self.geographic_model.analyze_geographic_impact(
                scenario_config['location'],
                scenario_config.get('terrain_type', 'urban_medium'),
                scenario_config.get('climate_zone', 'temperate'),
                scenario_config.get('elevation_m', 100),
                scenario_config
            )

        # Population and demographic analysis
        print("  Running population analysis...")
        if 'population_size' in scenario_config:
            model_results['population'] = self.population_model.analyze_population_impact(
                scenario_config.get('location_type', 'medium_city'),
                scenario_config['population_size'],
                scenario_config
            )

        # Military analysis (if conflict scenario)
        if scenario_type in ['conflict', 'military', 'war']:
            print("  Running military analysis...")

            # Basic military analysis
            if 'missile_threat' in scenario_config:
                missile_config = scenario_config['missile_threat']
                trajectory = self.military_analyzer.calculate_missile_trajectory(
                    missile_config['launch_coords'],
                    missile_config['target_coords'],
                    missile_config['missile_type'],
                    missile_config['missile_subtype']
                )

                defense_analysis = self.military_analyzer.calculate_defense_interception_probability(
                    trajectory,
                    scenario_config.get('defense_systems', ['Patriot PAC-3', 'THAAD']),
                    missile_config['target_coords']
                )

                casualty_analysis = self.military_analyzer.estimate_casualties_comprehensive(
                    trajectory,
                    scenario_config.get('target_area_data', {}),
                    missile_config.get('weapon_type', 'conventional')
                )

                model_results['military'] = {
                    'trajectory': trajectory,
                    'defense_analysis': defense_analysis,
                    'casualty_analysis': casualty_analysis
                }

            # Nuclear analysis (if nuclear scenario)
            if scenario_config.get('nuclear_escalation', False):
                print("  Running nuclear warfare analysis...")
                model_results['nuclear'] = self.nuclear_model.calculate_nuclear_exchange_scenario(
                    scenario_config['attacker_country'],
                    scenario_config['defender_country'],
                    scenario_config.get('escalation_level', 'limited'),
                    scenario_config.get('first_strike', False)
                )

        # Economic analysis
        print("  Running economic analysis...")
        if 'economic_warfare' in scenario_config or scenario_type == 'economic':
            model_results['economic'] = self.economic_model.calculate_economic_warfare_impact(
                scenario_config.get('attacker_country', 'Unknown'),
                scenario_config.get('target_country', 'USA'),
                scenario_config.get('warfare_type', 'sanctions'),
                scenario_config.get('intensity', 'medium'),
                scenario_config.get('duration_days', 180)
            )

        # Supply chain analysis
        if 'supply_chain_disruption' in scenario_config:
            print("  Running supply chain analysis...")
            model_results['supply_chain'] = self.supply_chain_model.analyze_supply_chain_disruption(
                scenario_config['supply_chain_disruption']['affected_nodes'],
                scenario_config['supply_chain_disruption']['affected_materials'],
                scenario_config['supply_chain_disruption']['disruption_intensity']
            )

        # Infrastructure analysis
        if 'infrastructure_impact' in scenario_config:
            print("  Running infrastructure analysis...")
            model_results['infrastructure'] = self.infrastructure_model.analyze_infrastructure_impact(
                scenario_config['infrastructure_impact']['profile'],
                scenario_config,
                model_results.get('geographic', {})
            )

        # Psychological impact analysis
        if 'population_size' in scenario_config:
            print("  Running psychological impact analysis...")
            model_results['psychological'] = self.psychological_model.analyze_psychological_impact(
                model_results.get('population', {}),
                scenario_config,
                scenario_config.get('duration_days', 30)
            )

        # Cultural impact analysis
        if 'cultural_region' in scenario_config:
            print("  Running cultural impact analysis...")
            model_results['cultural'] = self.cultural_model.analyze_cultural_impact(
                scenario_config['cultural_region'],
                model_results.get('population', {}),
                scenario_config
            )

        # Climate impact analysis (if long-term scenario)
        if scenario_config.get('time_horizon_years', 0) > 5:
            print("  Running climate impact analysis...")
            model_results['climate'] = self.climate_model.model_climate_impact_scenario(
                scenario_config.get('region', 'global'),
                scenario_config['time_horizon_years'],
                scenario_config.get('emission_scenario', 'rcp45'),
                model_results.get('population', {})
            )

        return model_results

    def _integrate_model_results(self, model_results, scenario_config):
        """Integrate results across all models to identify interactions and compound effects"""

        integrated_analysis = {
            'cross_model_interactions': {},
            'compound_effects': {},
            'feedback_loops': {},
            'system_vulnerabilities': {},
            'resilience_factors': {}
        }

        # Identify cross-model interactions
        integrated_analysis['cross_model_interactions'] = self._identify_cross_model_interactions(model_results)

        # Calculate compound effects
        integrated_analysis['compound_effects'] = self._calculate_compound_effects(model_results)

        # Identify feedback loops
        integrated_analysis['feedback_loops'] = self._identify_feedback_loops(model_results)

        # Assess system vulnerabilities
        integrated_analysis['system_vulnerabilities'] = self._assess_system_vulnerabilities(model_results)

        # Evaluate resilience factors
        integrated_analysis['resilience_factors'] = self._evaluate_resilience_factors(model_results)

        return integrated_analysis

    def _identify_cross_model_interactions(self, model_results):
        """Identify significant interactions between different model results"""

        interactions = {}

        # Military-Economic interactions
        if 'military' in model_results and 'economic' in model_results:
            military_casualties = model_results['military'].get('casualty_analysis', {}).get('immediate_casualties', 0)
            economic_damage = model_results['economic'].get('economic_damage', {}).get('total_damage_usd', 0)

            # Military action amplifies economic damage
            amplification_factor = 1 + (military_casualties / 100000) * 0.5
            adjusted_economic_damage = economic_damage * amplification_factor

            interactions['military_economic'] = {
                'casualty_economic_multiplier': amplification_factor,
                'adjusted_economic_damage': adjusted_economic_damage,
                'confidence_in_economic_systems': max(0.1, 1.0 - (military_casualties / 1000000))
            }

        # Population-Infrastructure interactions
        if 'population' in model_results and 'infrastructure' in model_results:
            displaced_population = model_results['population'].get('displacement_analysis', {}).get('total_displaced', 0)
            infrastructure_damage = model_results['infrastructure'].get('service_disruptions', {})

            # Population displacement affects infrastructure recovery
            recovery_delay_factor = 1 + (displaced_population / 100000) * 0.3

            interactions['population_infrastructure'] = {
                'displacement_recovery_delay': recovery_delay_factor,
                'workforce_availability': max(0.2, 1.0 - (displaced_population / 500000)),
                'infrastructure_maintenance_capacity': max(0.1, 1.0 - (displaced_population / 200000))
            }

        # Economic-Social interactions  
        if 'economic' in model_results and ('population' in model_results or 'psychological' in model_results):
            economic_damage_percent = 0
            if 'economic' in model_results:
                economic_damage_percent = model_results['economic'].get('economic_damage', {}).get('gdp_impact_percent', 0)

            # Economic damage affects social cohesion
            social_stress_multiplier = 1 + (economic_damage_percent / 10) * 0.8

            interactions['economic_social'] = {
                'economic_social_stress_multiplier': social_stress_multiplier,
                'unemployment_social_impact': economic_damage_percent * 2.5,
                'social_unrest_probability': min(0.8, economic_damage_percent / 20)
            }

        # Geographic-All Models interactions
        if 'geographic' in model_results:
            geographic_factors = model_results['geographic']
            terrain_accessibility = geographic_factors.get('logistics_factors', {}).get('accessibility_factor', 1.0)

            interactions['geographic_amplifiers'] = {
                'terrain_difficulty_multiplier': 2.0 - terrain_accessibility,
                'logistics_constraint_factor': terrain_accessibility,
                'evacuation_difficulty': 2.0 - terrain_accessibility,
                'recovery_access_factor': terrain_accessibility
            }

        return interactions

    def _calculate_compound_effects(self, model_results):
        """Calculate compound effects where multiple factors amplify each other"""

        compound_effects = {}

        # Calculate total casualty burden (direct + indirect)
        total_casualties = 0
        casualty_sources = []

        if 'military' in model_results:
            military_casualties = model_results['military'].get('casualty_analysis', {}).get('immediate_casualties', 0)
            total_casualties += military_casualties
            casualty_sources.append({'source': 'military', 'casualties': military_casualties})

        if 'infrastructure' in model_results:
            # Infrastructure failures cause indirect casualties
            infrastructure_casualties = self._estimate_infrastructure_casualties(model_results['infrastructure'])
            total_casualties += infrastructure_casualties
            casualty_sources.append({'source': 'infrastructure', 'casualties': infrastructure_casualties})

        if 'psychological' in model_results:
            # Mental health impacts lead to additional mortality
            psychological_mortality = self._estimate_psychological_mortality(model_results['psychological'])
            total_casualties += psychological_mortality
            casualty_sources.append({'source': 'psychological', 'casualties': psychological_mortality})

        compound_effects['total_casualty_burden'] = {
            'total_casualties': int(total_casualties),
            'casualty_sources': casualty_sources,
            'casualty_multiplier': total_casualties / max(1, casualty_sources[0]['casualties'] if casualty_sources else 1)
        }

        # Calculate compound economic impact
        total_economic_damage = 0
        economic_sources = []

        if 'economic' in model_results:
            direct_economic = model_results['economic'].get('economic_damage', {}).get('total_damage_usd', 0)
            total_economic_damage += direct_economic
            economic_sources.append({'source': 'direct_economic_warfare', 'damage': direct_economic})

        if 'supply_chain' in model_results:
            supply_chain_damage = model_results['supply_chain'].get('total_impact_with_cascade_usd', 0)
            total_economic_damage += supply_chain_damage
            economic_sources.append({'source': 'supply_chain', 'damage': supply_chain_damage})

        if 'infrastructure' in model_results:
            infrastructure_economic = model_results['infrastructure'].get('economic_impact', {}).get('total_damage_usd', 0)
            total_economic_damage += infrastructure_economic
            economic_sources.append({'source': 'infrastructure', 'damage': infrastructure_economic})

        compound_effects['total_economic_impact'] = {
            'total_damage_usd': total_economic_damage,
            'economic_sources': economic_sources,
            'gdp_impact_percent': (total_economic_damage / 25000000000000) * 100  # Global GDP rough estimate
        }

        # Calculate compound social disruption
        social_disruption_score = 0
        disruption_factors = []

        if 'population' in model_results:
            displacement_factor = model_results['population'].get('displacement_analysis', {}).get('displacement_rate_percent', 0) / 100
            social_disruption_score += displacement_factor * 0.4
            disruption_factors.append({'factor': 'displacement', 'score': displacement_factor})

        if 'psychological' in model_results:
            mental_health_factor = model_results['psychological'].get('mental_health_outcomes', {}).get('ptsd', {}).get('prevalence_rate', 0)
            social_disruption_score += mental_health_factor * 0.3
            disruption_factors.append({'factor': 'mental_health', 'score': mental_health_factor})

        if 'cultural' in model_results:
            cultural_disruption = model_results['cultural'].get('social_structure_changes', {}).get('social_cohesion_change', 0)
            cultural_factor = abs(cultural_disruption) / 10  # Normalize
            social_disruption_score += cultural_factor * 0.3
            disruption_factors.append({'factor': 'cultural_disruption', 'score': cultural_factor})

        compound_effects['social_disruption'] = {
            'total_disruption_score': min(1.0, social_disruption_score),
            'disruption_factors': disruption_factors,
            'social_cohesion_remaining': max(0, 1.0 - social_disruption_score)
        }

        return compound_effects

    def _generate_timeline_projections(self, integrated_analysis, scenario_config):
        """Generate timeline projections for scenario development"""

        duration_days = scenario_config.get('duration_days', 30)
        scenario_type = scenario_config.get('type', 'conflict')

        # Create timeline phases
        timeline_phases = self._define_timeline_phases(scenario_type, duration_days)

        # Project key metrics over time
        timeline_projections = {
            'phases': timeline_phases,
            'casualty_timeline': self._project_casualty_timeline(integrated_analysis, timeline_phases),
            'economic_impact_timeline': self._project_economic_timeline(integrated_analysis, timeline_phases),
            'infrastructure_recovery_timeline': self._project_infrastructure_timeline(integrated_analysis, timeline_phases),
            'social_recovery_timeline': self._project_social_timeline(integrated_analysis, timeline_phases),
            'escalation_probability_timeline': self._project_escalation_timeline(integrated_analysis, timeline_phases)
        }

        return timeline_projections

    def _define_timeline_phases(self, scenario_type, duration_days):
        """Define timeline phases based on scenario type"""

        if scenario_type in ['conflict', 'war', 'military']:
            return [
                {'phase': 'initial_impact', 'start_day': 0, 'end_day': min(7, duration_days * 0.1)},
                {'phase': 'escalation', 'start_day': min(7, duration_days * 0.1), 'end_day': min(30, duration_days * 0.3)},
                {'phase': 'sustained_conflict', 'start_day': min(30, duration_days * 0.3), 'end_day': min(duration_days * 0.8, duration_days - 30)},
                {'phase': 'resolution_phase', 'start_day': max(duration_days - 30, duration_days * 0.8), 'end_day': duration_days},
                {'phase': 'immediate_aftermath', 'start_day': duration_days, 'end_day': duration_days + 90},
                {'phase': 'recovery', 'start_day': duration_days + 90, 'end_day': duration_days + 365}
            ]
        elif scenario_type == 'economic':
            return [
                {'phase': 'initial_shock', 'start_day': 0, 'end_day': 14},
                {'phase': 'market_adjustment', 'start_day': 14, 'end_day': 60},
                {'phase': 'structural_adaptation', 'start_day': 60, 'end_day': duration_days},
                {'phase': 'recovery_phase', 'start_day': duration_days, 'end_day': duration_days + 180}
            ]
        else:  # Natural disaster or other
            return [
                {'phase': 'immediate_impact', 'start_day': 0, 'end_day': 3},
                {'phase': 'emergency_response', 'start_day': 3, 'end_day': 14},
                {'phase': 'stabilization', 'start_day': 14, 'end_day': 60},
                {'phase': 'recovery', 'start_day': 60, 'end_day': 365},
                {'phase': 'rebuilding', 'start_day': 365, 'end_day': 1095}  # 3 years
            ]

class EscalationModel:
    """Model for analyzing escalation dynamics and probability"""

    def __init__(self):
        self.escalation_triggers = self._load_escalation_triggers()
        self.de_escalation_factors = self._load_de_escalation_factors()
        self.threshold_models = self._load_threshold_models()

    def _load_escalation_triggers(self):
        """Load escalation trigger mechanisms"""
        return {
            'military': {
                'casualty_threshold': 1000,
                'infrastructure_damage_threshold': 0.3,
                'territory_loss_threshold': 0.1,
                'civilian_casualties_threshold': 500
            },
            'economic': {
                'gdp_impact_threshold': 0.05,
                'unemployment_threshold': 0.08,
                'inflation_threshold': 0.15,
                'currency_devaluation_threshold': 0.25
            },
            'political': {
                'regime_stability_threshold': 0.6,
                'public_support_threshold': 0.4,
                'international_isolation_threshold': 0.7,
                'internal_cohesion_threshold': 0.5
            },
            'social': {
                'displacement_threshold': 0.2,
                'social_unrest_threshold': 0.3,
                'institutional_breakdown_threshold': 0.4,
                'ethnic_tension_threshold': 0.6
            }
        }

    def calculate_escalation_probability(self, current_state, scenario_config, time_period_days):
        """Calculate probability of scenario escalation"""

        escalation_factors = {}

        # Analyze each category of escalation triggers
        for category, thresholds in self.escalation_triggers.items():
            category_risk = self._assess_category_escalation_risk(
                category, thresholds, current_state
            )
            escalation_factors[category] = category_risk

        # Calculate base escalation probability
        base_escalation_prob = sum(factor['risk_level'] for factor in escalation_factors.values()) / len(escalation_factors)

        # Apply time-dependent factors
        time_factor = self._calculate_time_escalation_factor(time_period_days)

        # Apply scenario-specific modifiers
        scenario_modifier = self._calculate_scenario_escalation_modifier(scenario_config)

        # Calculate final escalation probability
        final_escalation_prob = min(0.95, base_escalation_prob * time_factor * scenario_modifier)

        return {
            'escalation_probability': final_escalation_prob,
            'escalation_factors': escalation_factors,
            'time_factor': time_factor,
            'scenario_modifier': scenario_modifier,
            'escalation_triggers_activated': [
                category for category, factor in escalation_factors.items() 
                if factor['risk_level'] > 0.7
            ],
            'de_escalation_opportunities': self._identify_de_escalation_opportunities(escalation_factors)
        }

class GlobalResponseModel:
    """Model for international and global response to scenarios"""

    def __init__(self):
        self.country_relationships = self._load_country_relationships()
        self.international_organizations = self._load_international_organizations()
        self.response_mechanisms = self._load_response_mechanisms()

    def model_global_response(self, scenario_config, scenario_results):
        """Model comprehensive global response to scenario"""

        primary_actors = scenario_config.get('countries_involved', [])
        scenario_type = scenario_config.get('type', 'conflict')
        scenario_severity = self._assess_scenario_severity(scenario_results)

        global_response = {
            'immediate_responses': {},
            'diplomatic_initiatives': {},
            'economic_measures': {},
            'military_responses': {},
            'humanitarian_aid': {},
            'long_term_implications': {}
        }

        # Analyze immediate international responses
        global_response['immediate_responses'] = self._model_immediate_responses(
            primary_actors, scenario_type, scenario_severity
        )

        # Model diplomatic initiatives
        global_response['diplomatic_initiatives'] = self._model_diplomatic_responses(
            primary_actors, scenario_type, scenario_severity
        )

        # Analyze economic response measures
        global_response['economic_measures'] = self._model_economic_responses(
            primary_actors, scenario_type, scenario_severity, scenario_results
        )

        # Model potential military responses
        if scenario_type in ['conflict', 'military', 'war']:
            global_response['military_responses'] = self._model_military_responses(
                primary_actors, scenario_severity
            )

        # Calculate humanitarian aid requirements and responses
        global_response['humanitarian_aid'] = self._model_humanitarian_response(
            scenario_results, scenario_severity
        )

        # Assess long-term geopolitical implications
        global_response['long_term_implications'] = self._assess_long_term_implications(
            primary_actors, scenario_type, scenario_results
        )

        return global_response

    def _assess_scenario_severity(self, scenario_results):
        """Assess overall severity of scenario for international response"""

        severity_factors = {
            'casualty_severity': 0,
            'economic_severity': 0,
            'infrastructure_severity': 0,
            'social_severity': 0,
            'regional_stability_impact': 0
        }

        # Assess casualty severity
        if 'model_results' in scenario_results:
            model_results = scenario_results['model_results']

            if 'military' in model_results:
                casualties = model_results['military'].get('casualty_analysis', {}).get('immediate_casualties', 0)
                severity_factors['casualty_severity'] = min(1.0, casualties / 100000)  # Scale to 100k casualties = max

            if 'economic' in model_results:
                economic_damage = model_results['economic'].get('economic_damage', {}).get('gdp_impact_percent', 0)
                severity_factors['economic_severity'] = min(1.0, economic_damage / 20)  # Scale to 20% GDP impact = max

            if 'infrastructure' in model_results:
                infrastructure_impact = model_results['infrastructure'].get('service_disruptions', {})
                avg_disruption = np.mean([
                    service.get('disruption_rate', 0) 
                    for service in infrastructure_impact.values()
                ]) if infrastructure_impact else 0
                severity_factors['infrastructure_severity'] = avg_disruption

            if 'population' in model_results:
                displacement_rate = model_results['population'].get('displacement_analysis', {}).get('displacement_rate_percent', 0)
                severity_factors['social_severity'] = min(1.0, displacement_rate / 50)  # Scale to 50% displacement = max

        # Calculate regional stability impact
        severity_factors['regional_stability_impact'] = np.mean(list(severity_factors.values()))

        # Calculate overall severity score
        overall_severity = np.mean(list(severity_factors.values()))

        return {
            'overall_severity_score': overall_severity,
            'severity_factors': severity_factors,
            'severity_category': self._categorize_severity(overall_severity)
        }

    def _categorize_severity(self, severity_score):
        """Categorize severity score into levels"""
        if severity_score < 0.2:
            return 'low'
        elif severity_score < 0.4:
            return 'moderate'
        elif severity_score < 0.6:
            return 'high'
        elif severity_score < 0.8:
            return 'severe'
        else:
            return 'extreme'

    def run_experiment(self, experiment_id, experiment_config):
        """Run a built-in experiment scenario"""

        if experiment_id == 'india_pakistan_conflict':
            return self._run_india_pakistan_experiment(experiment_config)
        elif experiment_id == 'china_taiwan_scenario':
            return self._run_china_taiwan_experiment(experiment_config)
        elif experiment_id == 'middle_east_oil_crisis':
            return self._run_oil_crisis_experiment(experiment_config)
        elif experiment_id == 'pandemic_economic_collapse':
            return self._run_pandemic_experiment(experiment_config)
        elif experiment_id == 'cyber_warfare_escalation':
            return self._run_cyber_warfare_experiment(experiment_config)
        elif experiment_id == 'climate_refugee_crisis':
            return self._run_climate_refugee_experiment(experiment_config)
        else:
            raise ValueError(f"Unknown experiment ID: {experiment_id}")

    def _run_india_pakistan_experiment(self, config):
        """Run comprehensive India-Pakistan conflict scenario"""

        scenario_config = {
            'id': f'india_pakistan_{int(time.time())}',
            'type': 'conflict',
            'attacker_country': 'Pakistan',
            'defender_country': 'India',
            'countries_involved': ['India', 'Pakistan', 'China', 'USA'],
            'duration_days': 45,
            'intensity': 'high',
            'escalation_level': 'strategic',
            'nuclear_escalation': True,
            'population_size': 50000000,  # Affected population in border regions
            'location': 'Kashmir',
            'location_type': 'mountainous',
            'terrain_type': 'mountainous',
            'climate_zone': 'continental',
            'elevation_m': 2500,
            'cultural_region': 'south_asia',
            'missile_threat': {
                'launch_coords': [33.7782, 73.0610],  # Islamabad area
                'target_coords': [28.6139, 77.2090],  # Delhi area  
                'missile_type': 'ballistic_missiles',
                'missile_subtype': 'IRBM',
                'weapon_type': 'nuclear'
            },
            'defense_systems': ['S-400', 'Akash', 'Iron Dome'],
            'target_area_data': {
                'population_density': 25000,
                'area_type': 'urban',
                'protection_level': 0.15,
                'building_density': 0.7,
                'time_of_day': 'day'
            },
            'economic_warfare': True,
            'supply_chain_disruption': {
                'affected_nodes': ['India', 'Pakistan', 'China'],
                'affected_materials': ['textiles', 'agriculture', 'pharmaceuticals'],
                'disruption_intensity': 0.8
            },
            'infrastructure_impact': {
                'profile': {
                    'transportation': 0.6,
                    'energy': 0.8,
                    'telecommunications': 0.7,
                    'water_systems': 0.5
                }
            }
        }

        return self.run_comprehensive_analysis(scenario_config)
