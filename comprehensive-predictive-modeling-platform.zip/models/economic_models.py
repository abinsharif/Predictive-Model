
import numpy as np
import pandas as pd
import networkx as nx
from datetime import datetime, timedelta
import json
import math
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.preprocessing import StandardScaler
from collections import defaultdict

class EconomicImpactModel:
    """Comprehensive economic impact modeling system"""

    def __init__(self):
        self.country_economic_data = self._load_country_economic_data()
        self.sector_interdependencies = self._load_sector_interdependencies()
        self.global_trade_matrix = self._load_global_trade_matrix()
        self.economic_indicators = self._load_economic_indicators()

    def _load_country_economic_data(self):
        """Load comprehensive economic data for all countries"""
        return {
            'USA': {
                'gdp_trillion_usd': 26.9,
                'gdp_per_capita': 80412,
                'population': 331900000,
                'unemployment_rate': 3.4,
                'inflation_rate': 3.2,
                'debt_to_gdp_ratio': 106.7,
                'credit_rating': 'AAA',
                'economic_complexity_index': 1.46,
                'major_industries': ['technology', 'finance', 'healthcare', 'energy', 'defense'],
                'trade_dependence': 0.27,
                'currency_stability': 0.95,
                'financial_system_strength': 0.98
            },
            'China': {
                'gdp_trillion_usd': 17.9,
                'gdp_per_capita': 12556,
                'population': 1425671352,
                'unemployment_rate': 5.2,
                'inflation_rate': 2.1,
                'debt_to_gdp_ratio': 77.1,
                'credit_rating': 'A+',
                'economic_complexity_index': 0.47,
                'major_industries': ['manufacturing', 'technology', 'construction', 'agriculture'],
                'trade_dependence': 0.36,
                'currency_stability': 0.82,
                'financial_system_strength': 0.75
            },
            'Germany': {
                'gdp_trillion_usd': 4.26,
                'gdp_per_capita': 51203,
                'population': 83240525,
                'unemployment_rate': 5.6,
                'inflation_rate': 8.7,
                'debt_to_gdp_ratio': 69.7,
                'credit_rating': 'AAA',
                'economic_complexity_index': 1.88,
                'major_industries': ['automotive', 'machinery', 'chemicals', 'technology'],
                'trade_dependence': 0.84,
                'currency_stability': 0.92,
                'financial_system_strength': 0.89
            },
            'Japan': {
                'gdp_trillion_usd': 4.94,
                'gdp_per_capita': 39340,
                'population': 125584838,
                'unemployment_rate': 2.6,
                'inflation_rate': 3.0,
                'debt_to_gdp_ratio': 261.3,
                'credit_rating': 'A',
                'economic_complexity_index': 1.59,
                'major_industries': ['automotive', 'electronics', 'machinery', 'steel'],
                'trade_dependence': 0.35,
                'currency_stability': 0.87,
                'financial_system_strength': 0.93
            },
            'India': {
                'gdp_trillion_usd': 3.74,
                'gdp_per_capita': 2601,
                'population': 1428627663,
                'unemployment_rate': 7.8,
                'inflation_rate': 5.7,
                'debt_to_gdp_ratio': 89.6,
                'credit_rating': 'BBB-',
                'economic_complexity_index': 0.21,
                'major_industries': ['services', 'agriculture', 'manufacturing', 'textiles'],
                'trade_dependence': 0.42,
                'currency_stability': 0.73,
                'financial_system_strength': 0.68
            },
            'Pakistan': {
                'gdp_trillion_usd': 0.35,
                'gdp_per_capita': 1596,
                'population': 231402117,
                'unemployment_rate': 6.3,
                'inflation_rate': 29.2,
                'debt_to_gdp_ratio': 87.2,
                'credit_rating': 'CCC+',
                'economic_complexity_index': -0.59,
                'major_industries': ['textiles', 'agriculture', 'chemicals', 'food_processing'],
                'trade_dependence': 0.32,
                'currency_stability': 0.45,
                'financial_system_strength': 0.38
            },
            'Russia': {
                'gdp_trillion_usd': 1.83,
                'gdp_per_capita': 12654,
                'population': 144713314,
                'unemployment_rate': 3.7,
                'inflation_rate': 13.8,
                'debt_to_gdp_ratio': 18.9,
                'credit_rating': 'B',
                'economic_complexity_index': 0.25,
                'major_industries': ['oil_gas', 'mining', 'defense', 'agriculture'],
                'trade_dependence': 0.46,
                'currency_stability': 0.52,
                'financial_system_strength': 0.48
            },
            'Iran': {
                'gdp_trillion_usd': 0.23,
                'gdp_per_capita': 2757,
                'population': 85028759,
                'unemployment_rate': 11.2,
                'inflation_rate': 40.2,
                'debt_to_gdp_ratio': 48.1,
                'credit_rating': 'CCC',
                'economic_complexity_index': -0.21,
                'major_industries': ['oil_gas', 'petrochemicals', 'textiles', 'agriculture'],
                'trade_dependence': 0.25,
                'currency_stability': 0.28,
                'financial_system_strength': 0.31
            }
        }

    def _load_sector_interdependencies(self):
        """Load sector interdependency matrix"""
        return {
            'agriculture': {
                'depends_on': ['energy', 'transportation', 'manufacturing', 'water'],
                'supports': ['food_processing', 'retail', 'export'],
                'vulnerability_score': 0.7,
                'resilience_days': 30
            },
            'energy': {
                'depends_on': ['mining', 'transportation', 'technology', 'finance'],
                'supports': ['manufacturing', 'transportation', 'residential', 'commercial'],
                'vulnerability_score': 0.9,
                'resilience_days': 7
            },
            'manufacturing': {
                'depends_on': ['energy', 'raw_materials', 'transportation', 'labor'],
                'supports': ['retail', 'export', 'construction', 'technology'],
                'vulnerability_score': 0.8,
                'resilience_days': 14
            },
            'finance': {
                'depends_on': ['technology', 'energy', 'legal_framework'],
                'supports': ['all_sectors'],
                'vulnerability_score': 0.95,
                'resilience_days': 1
            },
            'healthcare': {
                'depends_on': ['energy', 'pharmaceuticals', 'technology', 'transportation'],
                'supports': ['workforce', 'population_stability'],
                'vulnerability_score': 0.6,
                'resilience_days': 21
            },
            'technology': {
                'depends_on': ['energy', 'semiconductors', 'rare_earth_materials'],
                'supports': ['all_sectors'],
                'vulnerability_score': 0.85,
                'resilience_days': 5
            },
            'transportation': {
                'depends_on': ['energy', 'infrastructure', 'technology'],
                'supports': ['all_sectors'],
                'vulnerability_score': 0.8,
                'resilience_days': 3
            }
        }

    def _load_global_trade_matrix(self):
        """Load global trade dependency matrix"""
        return {
            'semiconductors': {
                'primary_suppliers': ['Taiwan', 'South Korea', 'China'],
                'market_concentration': 0.89,
                'annual_trade_billion': 574,
                'substitution_difficulty': 0.95,
                'strategic_importance': 0.98
            },
            'oil_gas': {
                'primary_suppliers': ['Saudi Arabia', 'Russia', 'USA', 'Iran'],
                'market_concentration': 0.67,
                'annual_trade_billion': 2100,
                'substitution_difficulty': 0.3,
                'strategic_importance': 0.92
            },
            'rare_earth_elements': {
                'primary_suppliers': ['China', 'Australia', 'USA'],
                'market_concentration': 0.92,
                'annual_trade_billion': 8.5,
                'substitution_difficulty': 0.88,
                'strategic_importance': 0.85
            },
            'pharmaceuticals': {
                'primary_suppliers': ['China', 'India', 'Germany', 'USA'],
                'market_concentration': 0.72,
                'annual_trade_billion': 425,
                'substitution_difficulty': 0.65,
                'strategic_importance': 0.9
            },
            'food_grains': {
                'primary_suppliers': ['Russia', 'Ukraine', 'USA', 'Brazil'],
                'market_concentration': 0.58,
                'annual_trade_billion': 180,
                'substitution_difficulty': 0.4,
                'strategic_importance': 0.88
            }
        }

    def calculate_economic_warfare_impact(self, attacker, target, warfare_type, intensity, duration_days):
        """Calculate comprehensive economic warfare impact"""

        target_economy = self.country_economic_data[target]
        attacker_economy = self.country_economic_data.get(attacker, {})

        # Base economic damage calculation
        base_damage = self._calculate_base_economic_damage(target_economy, warfare_type, intensity)

        # Apply duration effects
        duration_multiplier = self._calculate_duration_multiplier(duration_days, warfare_type)

        # Calculate sectoral impacts
        sectoral_impacts = self._calculate_sectoral_impacts(target, warfare_type, intensity)

        # Calculate cascade effects
        cascade_effects = self._calculate_cascade_effects(sectoral_impacts, target)

        # Calculate international spillovers
        international_spillovers = self._calculate_international_spillovers(target, base_damage)

        total_economic_damage = base_damage * duration_multiplier + cascade_effects

        # GDP impact calculation
        gdp_impact_percent = min(50, (total_economic_damage / (target_economy['gdp_trillion_usd'] * 1e12)) * 100)

        # Employment impact
        unemployment_increase = self._calculate_unemployment_impact(gdp_impact_percent, sectoral_impacts)

        # Inflation impact
        inflation_increase = self._calculate_inflation_impact(warfare_type, intensity, sectoral_impacts)

        # Recovery timeline
        recovery_timeline = self._calculate_recovery_timeline(gdp_impact_percent, target_economy, warfare_type)

        return {
            'target_country': target,
            'warfare_type': warfare_type,
            'intensity_level': intensity,
            'duration_days': duration_days,
            'economic_damage': {
                'total_damage_usd': total_economic_damage,
                'base_damage_usd': base_damage,
                'cascade_effects_usd': cascade_effects,
                'gdp_impact_percent': gdp_impact_percent,
                'per_capita_loss_usd': total_economic_damage / target_economy['population']
            },
            'sectoral_impacts': sectoral_impacts,
            'macroeconomic_effects': {
                'unemployment_increase_percent': unemployment_increase,
                'inflation_increase_percent': inflation_increase,
                'currency_devaluation_percent': self._calculate_currency_impact(gdp_impact_percent, target_economy),
                'credit_rating_impact': self._calculate_credit_rating_impact(gdp_impact_percent, target_economy)
            },
            'recovery_analysis': recovery_timeline,
            'international_spillovers': international_spillovers,
            'strategic_assessment': self._assess_economic_warfare_effectiveness(total_economic_damage, target_economy)
        }

    def _calculate_base_economic_damage(self, target_economy, warfare_type, intensity):
        """Calculate base economic damage based on warfare type and intensity"""

        gdp_usd = target_economy['gdp_trillion_usd'] * 1e12

        # Base damage factors by warfare type
        damage_factors = {
            'sanctions': {
                'low': 0.02,      # 2% of GDP
                'medium': 0.08,   # 8% of GDP  
                'high': 0.18,     # 18% of GDP
                'extreme': 0.35   # 35% of GDP
            },
            'supply_chain_disruption': {
                'low': 0.03,
                'medium': 0.12,
                'high': 0.25,
                'extreme': 0.45
            },
            'financial_system_attack': {
                'low': 0.05,
                'medium': 0.15,
                'high': 0.35,
                'extreme': 0.60
            },
            'infrastructure_targeting': {
                'low': 0.04,
                'medium': 0.14,
                'high': 0.28,
                'extreme': 0.50
            },
            'cyber_warfare': {
                'low': 0.01,
                'medium': 0.06,
                'high': 0.18,
                'extreme': 0.40
            }
        }

        damage_factor = damage_factors.get(warfare_type, damage_factors['sanctions'])[intensity]

        # Apply country-specific vulnerabilities
        vulnerability_modifier = 1.0
        if target_economy['trade_dependence'] > 0.5:
            vulnerability_modifier += 0.3
        if target_economy['financial_system_strength'] < 0.7:
            vulnerability_modifier += 0.2
        if target_economy['currency_stability'] < 0.6:
            vulnerability_modifier += 0.4

        return gdp_usd * damage_factor * vulnerability_modifier

    def _calculate_sectoral_impacts(self, target_country, warfare_type, intensity):
        """Calculate impact on specific economic sectors"""

        target_economy = self.country_economic_data[target_country]
        sectoral_impacts = {}

        # Define sector vulnerability to different warfare types
        sector_vulnerabilities = {
            'sanctions': {
                'export_industries': 0.8,
                'finance': 0.6,
                'technology': 0.7,
                'energy': 0.5,
                'agriculture': 0.3
            },
            'supply_chain_disruption': {
                'manufacturing': 0.9,
                'technology': 0.85,
                'automotive': 0.8,
                'pharmaceuticals': 0.7,
                'agriculture': 0.4
            },
            'financial_system_attack': {
                'finance': 0.95,
                'real_estate': 0.7,
                'retail': 0.6,
                'manufacturing': 0.5,
                'services': 0.4
            },
            'infrastructure_targeting': {
                'energy': 0.9,
                'transportation': 0.85,
                'telecommunications': 0.8,
                'water_utilities': 0.75,
                'manufacturing': 0.6
            }
        }

        intensity_multipliers = {'low': 0.3, 'medium': 0.6, 'high': 0.8, 'extreme': 1.0}

        vulnerabilities = sector_vulnerabilities.get(warfare_type, sector_vulnerabilities['sanctions'])
        intensity_mult = intensity_multipliers[intensity]

        for sector, vulnerability in vulnerabilities.items():
            # Estimate sector size as percentage of GDP
            sector_gdp_share = self._estimate_sector_gdp_share(target_country, sector)
            sector_gdp_usd = target_economy['gdp_trillion_usd'] * 1e12 * sector_gdp_share

            # Calculate sector damage
            sector_damage = sector_gdp_usd * vulnerability * intensity_mult

            # Calculate employment impact
            sector_employment_share = self._estimate_sector_employment_share(target_country, sector)
            jobs_at_risk = int(target_economy['population'] * 0.6 * sector_employment_share * vulnerability * intensity_mult)

            sectoral_impacts[sector] = {
                'gdp_share_percent': sector_gdp_share * 100,
                'damage_usd': sector_damage,
                'damage_percent': vulnerability * intensity_mult * 100,
                'jobs_at_risk': jobs_at_risk,
                'recovery_months': self._estimate_sector_recovery_time(sector, vulnerability * intensity_mult)
            }

        return sectoral_impacts

    def _calculate_cascade_effects(self, sectoral_impacts, target_country):
        """Calculate economic cascade effects through supply chains"""

        total_cascade_damage = 0

        for affected_sector, impact in sectoral_impacts.items():
            sector_interdeps = self.sector_interdependencies.get(affected_sector, {})

            # Calculate upstream effects (suppliers affected)
            upstream_sectors = sector_interdeps.get('depends_on', [])
            for upstream_sector in upstream_sectors:
                if upstream_sector in sectoral_impacts:
                    continue  # Already directly impacted

                # Calculate indirect impact
                cascade_factor = 0.3  # 30% of direct impact cascades upstream
                indirect_damage = impact['damage_usd'] * cascade_factor
                total_cascade_damage += indirect_damage

            # Calculate downstream effects (customers affected)
            downstream_sectors = sector_interdeps.get('supports', [])
            for downstream_sector in downstream_sectors:
                if downstream_sector in sectoral_impacts:
                    continue  # Already directly impacted

                # Calculate indirect impact
                cascade_factor = 0.25  # 25% of direct impact cascades downstream
                indirect_damage = impact['damage_usd'] * cascade_factor
                total_cascade_damage += indirect_damage

        return total_cascade_damage

    def _calculate_international_spillovers(self, target_country, base_damage):
        """Calculate international economic spillovers"""

        target_economy = self.country_economic_data[target_country]

        # Calculate spillover based on country's global economic importance
        global_gdp_share = target_economy['gdp_trillion_usd'] / 104  # Global GDP ~104 trillion
        trade_intensity = target_economy['trade_dependence']

        spillovers = {}

        # Major trading partners affected
        major_economies = ['USA', 'China', 'Germany', 'Japan']

        for economy in major_economies:
            if economy == target_country:
                continue

            # Estimate trade relationship intensity
            trade_relationship = self._estimate_trade_relationship(target_country, economy)

            spillover_damage = base_damage * global_gdp_share * trade_relationship * 0.1

            spillovers[economy] = {
                'spillover_damage_usd': spillover_damage,
                'gdp_impact_percent': (spillover_damage / (self.country_economic_data[economy]['gdp_trillion_usd'] * 1e12)) * 100,
                'trade_relationship_strength': trade_relationship
            }

        # Global market effects
        spillovers['global_effects'] = {
            'stock_market_decline_percent': min(25, base_damage / 1e12 * 0.8),
            'commodity_price_volatility_increase': min(40, base_damage / 1e12 * 1.2),
            'international_trade_decline_percent': min(15, base_damage / 1e12 * 0.6)
        }

        return spillovers

    def _estimate_sector_gdp_share(self, country, sector):
        """Estimate sector's share of country GDP"""

        # Simplified sector GDP shares (would need real data)
        sector_shares = {
            'USA': {
                'finance': 0.21, 'technology': 0.18, 'healthcare': 0.12,
                'manufacturing': 0.12, 'energy': 0.08, 'agriculture': 0.01
            },
            'China': {
                'manufacturing': 0.28, 'construction': 0.14, 'finance': 0.08,
                'technology': 0.06, 'agriculture': 0.07, 'energy': 0.06
            },
            'Germany': {
                'manufacturing': 0.23, 'finance': 0.15, 'automotive': 0.12,
                'technology': 0.08, 'energy': 0.06, 'agriculture': 0.01
            }
        }

        country_sectors = sector_shares.get(country, {})
        return country_sectors.get(sector, 0.05)  # Default 5% if not found

    def _estimate_sector_employment_share(self, country, sector):
        """Estimate sector's share of total employment"""

        # Simplified employment shares
        employment_shares = {
            'manufacturing': 0.15,
            'services': 0.45,
            'agriculture': 0.08,
            'finance': 0.06,
            'technology': 0.04,
            'energy': 0.02,
            'healthcare': 0.12
        }

        return employment_shares.get(sector, 0.03)

    def _calculate_unemployment_impact(self, gdp_impact_percent, sectoral_impacts):
        """Calculate unemployment increase from economic damage"""

        # Okun's law: 1% GDP decline = ~2% unemployment increase
        base_unemployment_increase = gdp_impact_percent * 2

        # Add sector-specific effects
        sector_unemployment = sum(
            impact['jobs_at_risk'] for impact in sectoral_impacts.values()
        )

        # Convert to percentage increase
        # This is simplified - would need actual labor force data
        total_unemployment_increase = base_unemployment_increase + (sector_unemployment / 10000000)

        return min(25, total_unemployment_increase)  # Cap at 25% increase

    def _calculate_inflation_impact(self, warfare_type, intensity, sectoral_impacts):
        """Calculate inflation impact from economic warfare"""

        intensity_multipliers = {'low': 0.5, 'medium': 1.0, 'high': 1.8, 'extreme': 3.0}

        base_inflation_increase = {
            'sanctions': 2.0,
            'supply_chain_disruption': 4.0,
            'financial_system_attack': 3.0,
            'infrastructure_targeting': 3.5,
            'cyber_warfare': 1.5
        }

        base_increase = base_inflation_increase.get(warfare_type, 2.0)
        intensity_mult = intensity_multipliers[intensity]

        # Add sector-specific inflation effects
        sector_inflation = 0
        if 'energy' in sectoral_impacts:
            sector_inflation += sectoral_impacts['energy']['damage_percent'] * 0.3
        if 'agriculture' in sectoral_impacts:
            sector_inflation += sectoral_impacts['agriculture']['damage_percent'] * 0.2

        total_inflation_increase = (base_increase * intensity_mult) + (sector_inflation / 100 * 10)

        return min(50, total_inflation_increase)  # Cap at 50% increase

class SupplyChainModel:
    """Advanced global supply chain modeling system"""

    def __init__(self):
        self.supply_chain_network = self._build_supply_chain_network()
        self.critical_materials = self._load_critical_materials()
        self.transportation_routes = self._load_transportation_routes()

    def _build_supply_chain_network(self):
        """Build global supply chain network graph"""
        G = nx.DiGraph()

        # Add nodes (countries/regions)
        countries = ['USA', 'China', 'Germany', 'Japan', 'South Korea', 'Taiwan', 
                    'India', 'Russia', 'Saudi Arabia', 'Brazil', 'Australia', 'Canada']

        for country in countries:
            G.add_node(country)

        # Add critical supply chain edges with weights
        supply_relationships = [
            ('China', 'USA', {'material': 'rare_earths', 'dependency': 0.8, 'volume_billion': 15}),
            ('Taiwan', 'USA', {'material': 'semiconductors', 'dependency': 0.9, 'volume_billion': 120}),
            ('Saudi Arabia', 'USA', {'material': 'oil', 'dependency': 0.3, 'volume_billion': 45}),
            ('China', 'Germany', {'material': 'manufactured_goods', 'dependency': 0.6, 'volume_billion': 180}),
            ('Russia', 'Germany', {'material': 'natural_gas', 'dependency': 0.7, 'volume_billion': 85}),
            ('Australia', 'China', {'material': 'iron_ore', 'dependency': 0.8, 'volume_billion': 65}),
            ('Ukraine', 'global', {'material': 'wheat', 'dependency': 0.3, 'volume_billion': 8}),
            ('India', 'global', {'material': 'pharmaceuticals', 'dependency': 0.4, 'volume_billion': 25})
        ]

        for source, target, attrs in supply_relationships:
            G.add_edge(source, target, **attrs)

        return G

    def analyze_supply_chain_disruption(self, disrupted_nodes, disrupted_materials, disruption_intensity):
        """Analyze comprehensive supply chain disruption effects"""

        disruption_effects = {}

        for node in disrupted_nodes:
            node_effects = self._analyze_node_disruption(node, disrupted_materials, disruption_intensity)
            disruption_effects[node] = node_effects

        # Calculate global cascade effects
        cascade_effects = self._calculate_supply_chain_cascades(disrupted_nodes, disruption_intensity)

        # Calculate alternative routing costs
        alternative_routes = self._calculate_alternative_routes(disrupted_nodes, disrupted_materials)

        # Calculate recovery timeline
        recovery_analysis = self._analyze_supply_chain_recovery(disrupted_nodes, disruption_intensity)

        return {
            'disrupted_nodes': disrupted_nodes,
            'disrupted_materials': disrupted_materials,
            'disruption_intensity': disruption_intensity,
            'node_effects': disruption_effects,
            'cascade_effects': cascade_effects,
            'alternative_routes': alternative_routes,
            'recovery_analysis': recovery_analysis,
            'global_impact_summary': self._summarize_global_impact(disruption_effects, cascade_effects)
        }

    def _analyze_node_disruption(self, node, materials, intensity):
        """Analyze disruption effects for a specific node"""

        # Get all supply relationships from this node
        outgoing_edges = list(self.supply_chain_network.out_edges(node, data=True))

        node_disruption_effects = {
            'direct_trade_loss_billion': 0,
            'dependent_countries': [],
            'material_shortages': {},
            'price_increases': {}
        }

        for source, target, attrs in outgoing_edges:
            material = attrs['material']
            if materials == 'all' or material in materials:
                dependency = attrs['dependency']
                volume = attrs['volume_billion']

                # Calculate disruption based on intensity and dependency
                disruption_factor = intensity * dependency
                trade_loss = volume * disruption_factor

                node_disruption_effects['direct_trade_loss_billion'] += trade_loss
                node_disruption_effects['dependent_countries'].append({
                    'country': target,
                    'material': material,
                    'dependency_loss': disruption_factor,
                    'trade_loss_billion': trade_loss
                })

                # Calculate material shortages
                shortage_percent = disruption_factor * 100
                node_disruption_effects['material_shortages'][material] = shortage_percent

                # Calculate price increases (shortage drives prices up)
                price_increase_percent = shortage_percent * 1.5  # Price elasticity factor
                node_disruption_effects['price_increases'][material] = min(300, price_increase_percent)

        return node_disruption_effects

    def _calculate_supply_chain_cascades(self, disrupted_nodes, intensity):
        """Calculate cascade effects through supply chain network"""

        cascade_effects = {}

        # Use network analysis to find cascade paths
        for node in self.supply_chain_network.nodes():
            if node in disrupted_nodes:
                continue

            # Calculate indirect effects on this node
            indirect_impact = 0
            affected_materials = set()

            for disrupted_node in disrupted_nodes:
                # Find all paths from disrupted node to current node
                try:
                    paths = list(nx.all_simple_paths(
                        self.supply_chain_network, 
                        disrupted_node, 
                        node, 
                        cutoff=3  # Max 3 hops
                    ))

                    for path in paths:
                        # Calculate impact along this path
                        path_impact = intensity
                        for i in range(len(path) - 1):
                            edge_data = self.supply_chain_network[path[i]][path[i+1]]
                            path_impact *= edge_data['dependency'] * 0.7  # Cascade dampening
                            affected_materials.add(edge_data['material'])

                        indirect_impact = max(indirect_impact, path_impact)

                except nx.NetworkXNoPath:
                    continue

            if indirect_impact > 0.1:  # Only record significant cascades
                cascade_effects[node] = {
                    'indirect_impact_factor': indirect_impact,
                    'affected_materials': list(affected_materials),
                    'estimated_economic_loss_billion': indirect_impact * 5  # Rough scaling
                }

        return cascade_effects

class MarketDisruptionModel:
    """Financial market disruption modeling system"""

    def __init__(self):
        self.market_correlations = self._load_market_correlations()
        self.volatility_models = self._load_volatility_models()
        self.sector_sensitivities = self._load_sector_sensitivities()

    def model_market_disruption(self, trigger_event, trigger_magnitude, affected_markets):
        """Model comprehensive market disruption effects"""

        market_effects = {}

        for market in affected_markets:
            market_impact = self._calculate_market_impact(market, trigger_event, trigger_magnitude)
            market_effects[market] = market_impact

        # Calculate cross-market contagion
        contagion_effects = self._calculate_market_contagion(market_effects)

        # Model volatility spillovers
        volatility_effects = self._model_volatility_spillovers(trigger_event, trigger_magnitude)

        return {
            'trigger_event': trigger_event,
            'trigger_magnitude': trigger_magnitude,
            'direct_market_effects': market_effects,
            'contagion_effects': contagion_effects,
            'volatility_spillovers': volatility_effects,
            'recovery_timeline': self._estimate_market_recovery(market_effects, trigger_magnitude)
        }

    def _calculate_market_impact(self, market, trigger_event, magnitude):
        """Calculate direct impact on specific market"""

        # Market sensitivity to different events
        event_sensitivities = {
            'geopolitical_conflict': {
                'equity': -0.15, 'bond': 0.08, 'commodity': 0.25, 'currency': -0.12, 'crypto': -0.30
            },
            'economic_warfare': {
                'equity': -0.20, 'bond': 0.05, 'commodity': 0.30, 'currency': -0.18, 'crypto': -0.25
            },
            'supply_chain_crisis': {
                'equity': -0.12, 'bond': 0.03, 'commodity': 0.40, 'currency': -0.08, 'crypto': -0.15
            },
            'nuclear_threat': {
                'equity': -0.35, 'bond': 0.20, 'commodity': 0.50, 'currency': -0.25, 'crypto': -0.40
            }
        }

        base_impact = event_sensitivities.get(trigger_event, {}).get(market, -0.10)
        scaled_impact = base_impact * magnitude

        # Add volatility increase
        volatility_increase = abs(scaled_impact) * 2.5

        return {
            'market_type': market,
            'price_impact_percent': scaled_impact * 100,
            'volatility_increase_percent': volatility_increase * 100,
            'volume_change_percent': abs(scaled_impact) * 150,  # Higher activity during crisis
            'liquidity_impact_percent': abs(scaled_impact) * 80   # Reduced liquidity
        }

    def _calculate_market_contagion(self, market_effects):
        """Calculate contagion effects between markets"""

        # Market correlation matrix (simplified)
        correlations = {
            'equity': {'bond': -0.3, 'commodity': 0.4, 'currency': 0.6, 'crypto': 0.5},
            'bond': {'commodity': -0.2, 'currency': -0.4, 'crypto': -0.1},
            'commodity': {'currency': 0.3, 'crypto': 0.2},
            'currency': {'crypto': 0.3}
        }

        contagion_effects = {}

        for market1, effect1 in market_effects.items():
            for market2, effect2 in market_effects.items():
                if market1 >= market2:  # Avoid duplicates
                    continue

                correlation = correlations.get(market1, {}).get(market2, 0)

                if abs(correlation) > 0.2:  # Significant correlation
                    contagion_factor = correlation * 0.6  # Contagion dampening

                    contagion_effects[f"{market1}_to_{market2}"] = {
                        'correlation': correlation,
                        'contagion_impact_percent': effect1['price_impact_percent'] * contagion_factor,
                        'amplification_factor': abs(contagion_factor)
                    }

        return contagion_effects
